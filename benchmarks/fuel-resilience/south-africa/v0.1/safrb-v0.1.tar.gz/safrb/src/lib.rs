#![forbid(unsafe_code)]

use std::collections::{BTreeMap, HashSet};

/// Epistemic class of a value. This is deliberately separate from the physical
/// state of a stock or cargo record.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EvidenceClass {
    Measured,
    Reported,
    Derived,
    Scenario,
    Forecast,
    Simulated,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum StockStatus {
    ReportedPhysical,
    MeasuredPhysical,
    VerifiedUsable,
    Committed,
    PipelineLineFill,
    CargoNominated,
    CargoLoaded,
    CargoDeparted,
    CargoInTransit,
    CargoArrived,
    CargoDischarged,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct EvidenceRef {
    pub source_id: String,
    pub source_uri: String,
    pub evidence_class: EvidenceClass,
    /// UTC epoch seconds for when the observation is valid in the world.
    pub valid_at_utc: i64,
    /// UTC epoch seconds for when the source published/recorded it.
    pub recorded_at_utc: i64,
    pub raw_sha256: Option<String>,
    pub uncertainty_low_l: Option<u64>,
    pub uncertainty_high_l: Option<u64>,
}

impl EvidenceRef {
    pub fn validate(&self) -> Result<(), String> {
        if self.source_id.trim().is_empty() {
            return Err("evidence source_id must not be empty".into());
        }
        if self.source_uri.trim().is_empty() {
            return Err("evidence source_uri must not be empty".into());
        }
        if self.recorded_at_utc < self.valid_at_utc {
            // Publication may precede validity for forecasts, but this v0.1
            // reference is intentionally an observation record. Forecasts are
            // a separate evidence class and are allowed to lead valid time.
            if self.evidence_class != EvidenceClass::Forecast {
                return Err("recorded_at_utc precedes valid_at_utc for a non-forecast record".into());
            }
        }
        if let (Some(low), Some(high)) = (self.uncertainty_low_l, self.uncertainty_high_l) {
            if low > high {
                return Err("uncertainty_low_l exceeds uncertainty_high_l".into());
            }
        }
        if let Some(digest) = &self.raw_sha256 {
            if digest.len() != 64 || !digest.chars().all(|c| c.is_ascii_hexdigit()) {
                return Err("raw_sha256 must be exactly 64 hexadecimal characters".into());
            }
        }
        Ok(())
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct InventoryObservation {
    pub observation_id: String,
    pub location_id: String,
    pub product_grade: String,
    pub status: StockStatus,
    pub volume_l: u64,
    pub quality_released: bool,
    pub physically_accessible: bool,
    pub evidence: EvidenceRef,
}

impl InventoryObservation {
    pub fn validate(&self) -> Result<(), String> {
        if self.observation_id.trim().is_empty() {
            return Err("observation_id must not be empty".into());
        }
        if self.location_id.trim().is_empty() {
            return Err("location_id must not be empty".into());
        }
        if self.product_grade.trim().is_empty() {
            return Err("product_grade must not be empty".into());
        }
        self.evidence.validate()?;

        match self.status {
            StockStatus::VerifiedUsable => {
                if self.evidence.evidence_class != EvidenceClass::Measured {
                    return Err("VerifiedUsable requires measured evidence".into());
                }
                if self.evidence.raw_sha256.is_none() {
                    return Err("VerifiedUsable requires a raw measurement digest".into());
                }
                if !self.quality_released {
                    return Err("VerifiedUsable requires a product-quality release".into());
                }
                if !self.physically_accessible {
                    return Err("VerifiedUsable requires physical accessibility attestation".into());
                }
            }
            StockStatus::MeasuredPhysical => {
                if self.evidence.evidence_class != EvidenceClass::Measured {
                    return Err("MeasuredPhysical requires measured evidence".into());
                }
            }
            StockStatus::ReportedPhysical => {
                if self.evidence.evidence_class != EvidenceClass::Reported {
                    return Err("ReportedPhysical requires reported evidence".into());
                }
            }
            _ => {}
        }
        Ok(())
    }

    /// Only stock independently measured, quality-released and physically
    /// accessible is admitted to the immediately-usable opening inventory.
    pub fn immediately_usable_l(&self) -> u64 {
        if self.status == StockStatus::VerifiedUsable
            && self.quality_released
            && self.physically_accessible
            && self.evidence.evidence_class == EvidenceClass::Measured
        {
            self.volume_l
        } else {
            0
        }
    }
}

pub fn aggregate_verified_usable_l(
    observations: &[InventoryObservation],
) -> Result<u64, String> {
    let mut total = 0_u64;
    let mut ids = HashSet::new();
    for observation in observations {
        observation.validate()?;
        if !ids.insert(observation.observation_id.as_str()) {
            return Err(format!("duplicate observation_id: {}", observation.observation_id));
        }
        total = total
            .checked_add(observation.immediately_usable_l())
            .ok_or_else(|| "usable inventory sum overflowed u64".to_string())?;
    }
    Ok(total)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum CargoMilestone {
    Nominated,
    Loaded,
    Departed,
    InTransit,
    Arrived,
    Discharged,
}

impl CargoMilestone {
    fn next(self) -> Option<Self> {
        match self {
            Self::Nominated => Some(Self::Loaded),
            Self::Loaded => Some(Self::Departed),
            Self::Departed => Some(Self::InTransit),
            Self::InTransit => Some(Self::Arrived),
            Self::Arrived => Some(Self::Discharged),
            Self::Discharged => None,
        }
    }
}

/// Minimal event-state register. A cargo is a commitment/flow observation,
/// never inventory merely because it was nominated, loaded or arrived.
#[derive(Debug, Default)]
pub struct CargoRegister {
    milestones: BTreeMap<String, CargoMilestone>,
}

impl CargoRegister {
    pub fn advance(&mut self, cargo_id: &str, next: CargoMilestone) -> Result<(), String> {
        if cargo_id.trim().is_empty() {
            return Err("cargo_id must not be empty".into());
        }
        match self.milestones.get(cargo_id).copied() {
            None if next == CargoMilestone::Nominated => {
                self.milestones.insert(cargo_id.to_string(), next);
                Ok(())
            }
            None => Err("cargo must begin at Nominated".into()),
            Some(current) if current.next() == Some(next) => {
                self.milestones.insert(cargo_id.to_string(), next);
                Ok(())
            }
            Some(current) => Err(format!(
                "invalid cargo transition for {cargo_id}: {current:?} -> {next:?}"
            )),
        }
    }

    pub fn milestone(&self, cargo_id: &str) -> Option<CargoMilestone> {
        self.milestones.get(cargo_id).copied()
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Disruption {
    pub start_day: u16,
    pub duration_days: u16,
    /// Values are basis points: 10_000 = 100% reduction.
    pub import_cut_bps: u16,
    pub production_cut_bps: u16,
    pub demand_reduction_bps: u16,
    /// Additional zero-arrival days from the start of the disruption.
    pub import_delay_days: u16,
}

impl Disruption {
    fn validate(self, horizon_days: u16) -> Result<(), String> {
        if self.duration_days == 0 {
            return Err("disruption duration_days must be greater than zero".into());
        }
        for (name, value) in [
            ("import_cut_bps", self.import_cut_bps),
            ("production_cut_bps", self.production_cut_bps),
            ("demand_reduction_bps", self.demand_reduction_bps),
        ] {
            if value > 10_000 {
                return Err(format!("{name} must be in 0..=10000"));
            }
        }
        if self.start_day >= horizon_days {
            return Err("disruption starts outside the simulation horizon".into());
        }
        if self.start_day.saturating_add(self.duration_days) > horizon_days {
            return Err("disruption extends beyond the simulation horizon".into());
        }
        Ok(())
    }

    fn active(self, day: u16) -> bool {
        day >= self.start_day && day < self.start_day.saturating_add(self.duration_days)
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ScenarioConfig {
    pub scenario_id: String,
    pub horizon_days: u16,
    pub opening_verified_usable_l: u64,
    pub storage_capacity_l: u64,
    pub daily_domestic_production_l: u64,
    pub daily_import_discharge_l: u64,
    pub daily_demand_l: u64,
    /// Aggregate ceiling on import receipts; v0.1 does not yet model individual
    /// ports, pipeline arcs, product batches or provincial depots.
    pub max_import_receipts_l_per_day: u64,
    pub disruption: Option<Disruption>,
}

impl ScenarioConfig {
    pub fn validate(&self) -> Result<(), String> {
        if self.scenario_id.trim().is_empty() {
            return Err("scenario_id must not be empty".into());
        }
        if self.horizon_days == 0 {
            return Err("horizon_days must be greater than zero".into());
        }
        if self.opening_verified_usable_l > self.storage_capacity_l {
            return Err("opening usable inventory exceeds storage capacity".into());
        }
        if self.daily_demand_l == 0 {
            return Err("daily_demand_l must be greater than zero".into());
        }
        if let Some(disruption) = self.disruption {
            disruption.validate(self.horizon_days)?;
        }
        Ok(())
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DayResult {
    pub day: u16,
    pub opening_inventory_l: u64,
    pub domestic_production_l: u64,
    pub import_receipts_l: u64,
    pub demand_l: u64,
    pub delivered_l: u64,
    pub unserved_l: u64,
    pub storage_overflow_l: u64,
    pub closing_inventory_l: u64,
    pub material_balance_residual_l: i128,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ScenarioResult {
    pub scenario_id: String,
    pub days: Vec<DayResult>,
    pub first_shortfall_day: Option<u16>,
    pub cumulative_demand_l: u64,
    pub cumulative_delivered_l: u64,
    pub cumulative_unserved_l: u64,
    pub ending_inventory_l: u64,
    pub max_absolute_balance_residual_l: u64,
}

fn scale_by_remaining_bps(volume_l: u64, cut_bps: u16) -> Result<u64, String> {
    let remaining = 10_000_u64 - u64::from(cut_bps);
    let scaled = u128::from(volume_l) * u128::from(remaining) / 10_000;
    u64::try_from(scaled).map_err(|_| "scaled volume exceeds u64".to_string())
}

pub fn simulate(config: &ScenarioConfig) -> Result<ScenarioResult, String> {
    config.validate()?;
    let mut inventory = config.opening_verified_usable_l;
    let mut days = Vec::with_capacity(usize::from(config.horizon_days));
    let mut first_shortfall_day = None;
    let mut cumulative_demand = 0_u64;
    let mut cumulative_delivered = 0_u64;
    let mut cumulative_unserved = 0_u64;
    let mut max_residual = 0_u64;

    for day in 0..config.horizon_days {
        let opening = inventory;
        let active = config.disruption.is_some_and(|shock| shock.active(day));
        let shock = config.disruption;

        let production_cut = if active { shock.map_or(0, |s| s.production_cut_bps) } else { 0 };
        let import_cut = if active { shock.map_or(0, |s| s.import_cut_bps) } else { 0 };
        let demand_reduction = if active {
            shock.map_or(0, |s| s.demand_reduction_bps)
        } else {
            0
        };

        let production = scale_by_remaining_bps(config.daily_domestic_production_l, production_cut)?;
        let mut imports = scale_by_remaining_bps(config.daily_import_discharge_l, import_cut)?;
        if active && shock.is_some_and(|s| day < s.start_day.saturating_add(s.import_delay_days)) {
            imports = 0;
        }
        imports = imports.min(config.max_import_receipts_l_per_day);
        let demand = scale_by_remaining_bps(config.daily_demand_l, demand_reduction)?;

        let available = opening
            .checked_add(production)
            .and_then(|x| x.checked_add(imports))
            .ok_or_else(|| "daily supply or inventory overflowed u64".to_string())?;
        let delivered = available.min(demand);
        let unserved = demand - delivered;
        if unserved > 0 && first_shortfall_day.is_none() {
            first_shortfall_day = Some(day + 1);
        }
        let provisional_closing = available - delivered;
        let closing = provisional_closing.min(config.storage_capacity_l);
        let overflow = provisional_closing - closing;
        let residual = i128::from(opening)
            + i128::from(production)
            + i128::from(imports)
            - i128::from(delivered)
            - i128::from(overflow)
            - i128::from(closing);
        let residual_abs = residual.unsigned_abs();
        max_residual = max_residual.max(u64::try_from(residual_abs).unwrap_or(u64::MAX));

        cumulative_demand = cumulative_demand
            .checked_add(demand)
            .ok_or_else(|| "cumulative demand overflowed u64".to_string())?;
        cumulative_delivered = cumulative_delivered
            .checked_add(delivered)
            .ok_or_else(|| "cumulative deliveries overflowed u64".to_string())?;
        cumulative_unserved = cumulative_unserved
            .checked_add(unserved)
            .ok_or_else(|| "cumulative unserved demand overflowed u64".to_string())?;

        days.push(DayResult {
            day: day + 1,
            opening_inventory_l: opening,
            domestic_production_l: production,
            import_receipts_l: imports,
            demand_l: demand,
            delivered_l: delivered,
            unserved_l: unserved,
            storage_overflow_l: overflow,
            ing_inventory_l: u64,ing_inv,
            material_balance_residual_l: residual,
        });
        inventory = closing;
    }

    Ok(ScenarioResult {
        scenario_id: config.scenario_id.clone(),
        days,
        first_shortfall_day,
        cumulative_demandu64,iumulative_demand,
        cumulative_delivered_l: cumulative_delivered,
        cumulative_unserved_l: cumulative_unserved,
        ending_inventory_l: inventory,
        max_absolute_balance_residual_l: max_residual,
    })
}

/// Canonical 7/14/30/60/90-day import-shock family. The 30-day post-shock
/// tail makes recovery dynamics visible. These are stress-test durations, not
/// forecasts. The caller supplies every physical quantity and assumption.
pub fn canonical_disruption_suite(
    base: &ScenarioConfig,
    import_cut_bps: u16,
) -> Result<Vec<ScenarioConfig>, String> {
    if import_cut_bps > 10_000 {
        return Err("import_cut_bps must be in 0..=10000".into());
    }
    let mut scenarios = Vec::new();
    for duration in [7_u16, 14, 30, 60, 90] {
        let horizon = duration
            .checked_add(30)
            .ok_or_else(|| "scenario horizon overflow".to_string())?;
        let mut scenario = base.clone();
        scenario.scenario_id = format!("import-shock-{duration}d");
        scenario.horizon_days = horizon;
        scenario.disruption = Some(Disruption {
            start_day: 0,
            duration_days: duration,
            import_cut_bps,
            production_cut_bps: 0,
            demand_reduction_bps: 0,
            import_delay_days: 0,
        });
        scenario.validate()?;
        scenarios.push(scenario);
    }
    Ok(scenarios)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn evidence(class: EvidenceClass) -> EvidenceRef {
        EvidenceRef {
            source_id: "fixture-source".into(),
            source_uri: "https://example.invalid/fixture".into(),
            evidence_class: class,
            valid_at_utc: 1_000,
            recorded_at_utc: 1_100,
            raw_sha256: Some("a".repeat(64)),
            uncertainty_low_l: Some(90),
            uncertainty_high_l: Some(110),
        }
    }

    fn observation(status: StockStatus, class: EvidenceClass) -> InventoryObservation {
        InventoryObservation {
            observation_id: format!("obs-{status:?}"),
            location_id: "fixture-terminal".into(),
            product_grade: "D50".into(),
            status,
            volume_l: 100,
            quality_released: true,
            physically_accessible: true,
            evidence: evidence(class),
        }
    }

    fn base_config() -> ScenarioConfig {
        ScenarioConfig {
            scenario_id: "test-base".into(),
            horizon_days: 37,
            opening_verified_usable_l: 700,
            storage_capacity_l: 10_000,
            daily_domestic_production_l: 300,
            daily_import_discharge_l: 700,
            daily_demand_l: 1_000,
            max_import_receipts_l_per_day: 1_000,
            disruption: Some(Disruption {
                start_day: 0,
                duration_days: 7,
                import_cut_bps: 10_000,
                production_cut_bps: 0,
                demand_reduction_bps: 0,
                import_delay_days: 0,
            }),
        }
    }

    #[test]
    fn only_verified_usable_inventory_is_counted() {
        let items = vec![
            observation(StockStatus::ReportedPhysical, EvidenceClass::Reported),
            observation(StockStatus::MeasuredPhysical, EvidenceClass::Measured),
            observation(StockStatus::PipelineLineFill, EvidenceClass::Reported),
            observation(StockStatus::CargoInTransit, EvidenceClass::Reported),
            observation(StockStatus::VerifiedUsable, EvidenceClass::Measured),
        ];
        assert_eq!(aggregate_verified_usable_l(&items).unwrap(), 100);
    }

    #[test]
    fn verified_usable_requires_measurement_quality_and_access() {
        let mut item = observation(StockStatus::VerifiedUsable, EvidenceClass::Reported);
        assert!(item.validate().is_err());
        item.evidence = evidence(EvidenceClass::Measured);
        item.quality_released = false;
        assert!(item.validate().is_err());
        item.quality_released = true;
        item.physically_accessible = false;
        assert!(item.validate().is_err());
    }

    #[test]
    fn invalid_uncertainty_and_digest_are_rejected() {
        let mut item = observation(StockStatus::MeasuredPhysical, EvidenceClass::Measured);
        item.evidence.uncertainty_low_l = Some(200);
        item.evidence.uncertainty_high_l = Some(100);
        assert!(item.validate().is_err());
        item.evidence.uncertainty_low_l = Some(90);
        item.evidence.uncertainty_high_l = Some(110);
        item.evidence.raw_sha256 = Some("bad-digest".into());
        assert!(item.validate().is_err());
    }

    #[test]
    fn duplicate_inventory_observation_ids_are_rejected() {
        let item = observation(StockStatus::VerifiedUsable, EvidenceClass::Measured);
        assert!(aggregate_verified_usable_l(&[item.clone(), item]).is_err());
    }

    #[test]
    fn cargo_must_follow_monotonic_milestones() {
        let mut registry = CargoRegister::default();
        assert!(registry.advance("cargo-1", CargoMilestone::Arrived).is_err());
        registry.advance("cargo-1", CargoMilestone::Nominated).unwrap();
        registry.advance("cargo-1", CargoMilestone::Loaded).unwrap();
        registry.advance("cargo-1", CargoMilestone::Departed).unwrap();
        registry.advance("cargo-1", CargoMilestone::InTransit).unwrap();
        registry.advance("cargo-1", CargoMilestone::Arrived).unwrap();
        registry.advance("cargo-1", CargoMilestone::Discharged).unwrap();
        assert!(registry.advance("cargo-1", CargoMilestone::Discharged).is_err());
    }

    #[test]
    fn nominated_or_arrived_cargo_is_not_automatically_usable_stock() {
        let nominated = observation(StockStatus::CargoNominated, EvidenceClass::Reported);
        let arrived = observation(StockStatus::CargoArrived, EvidenceClass::Reported);
        assert_eq!(nominated.immediately_usable_l(), 0);
        assert_eq!(arrived.immediately_usable_l(), 0);
    }

    #[test]
    fn every_day_satisfies_material_balance_identity() {
        let result = simulate(&base_config()).unwrap();
        assert!(result.days.iter().all(|day| day.material_balance_residual_l == 0));
        assert_eq!(result.max_absolute_balance_residual_l, 0);
    }

    #[test]
    fn inventory_never_goes_negative_and_shortfall_is_explicit() {
        let result = simulate(&base_config()).unwrap();
        assert!(result.days.iter().all(|day| day.ing_inventory_l: u6 <= 10_000));
        assert!(result.days.iter().all(|day| day.unserved_l <= day.demand_l));
        assert_eq!(result.first_shortfall_day, Some(2));
    }

    #[test]
    fn canonical_suite_has_the_five_required_durations() {
        let suite = canonical_disruption_suite(&base_config(), 10_000).unwrap();
        let durations: Vec<u16> = suite
            .iter()
            .map(|scenario| scenario.disruption.unwrap().duration_days)
            .collect();
        assert_eq!(durations, vec![7, 14, 30, 60, 90]);
        assert_eq!(suite[0].horizon_days, 37);
        assert_eq!(suite[4].horizon_days, 120);
    }

    #[test]
    fn import_delay_and_production_cut_are_separate_shock_dimensions() {
        let mut config = base_config();
        config.opening_verified_usable_l = 0;
        config.daily_import_discharge_l = 700;
        config.disruption = Some(Disruption {
            start_day: 0,
            duration_days: 7,
            import_cut_bps: 0,
            production_cut_bps: 5_000,
            demand_reduction_bps: 0,
            import_delay_days: 3,
        });
        let result = simulate(&config).unwrap();
        assert_eq!(result.days[0].domestic_production_l, 150);
        assert_eq!(result.days[0].import_receipts_l, 0);
        assert_eq!(result.days[2].import_receipts_l, 0);
        assert_eq!(result.days[3].import_receipts_l, 700);
    }

    #[test]
    fn demand_response_changes_demand_not_physical_supply() {
        let mut config = base_config();
        config.disruption = Some(Disruption {
            start_day: 0,
            duration_days: 1,
            import_cut_bps: 0,
            production_cut_bps: 0,
            demand_reduction_bps: 2_000,
            import_delay_days: 0,
        });
        let result = simulate(&config).unwrap();
        assert_eq!(result.days[0].domestic_production_l, 300);
        assert_eq!(result.days[0].import_receipts_l, 700);
        assert_eq!(result.days[0].demand_l, 800);
        assert_eq!(result.days[0].ing_inventory_l: u6, 900);
    }

    #[test]
    fn storage_overflow_is_explicit_and_mass_balanced() {
        let config = ScenarioConfig {
            scenario_id: "capacity-overflow-control".into(),
            horizon_days: 1,
            opening_verified_usable_l: 0,
            storage_capacity_l: 500,
            daily_domestic_production_l: 1_000,
            daily_import_discharge_l: 1_000,
            daily_demand_l: 100,
            max_import_receipts_l_per_day: 2_000,
            disruption: None,
        };
        let result = simulate(&config).unwrap();
        assert_eq!(result.days[0].delivered_l, 100);
        assert_eq!(result.days[0].storage_overflow_l, 1_400);
        assert_eq!(result.days[0].ing_inventory_l: u6, 500);
        assert_eq!(result.days[0].material_balance_residual_l, 0);
    }

    #[test]
    fn impossibleentputs_fail_closed() {
        let mut config = base_config();
        config.opening_verified_usable_l = config.storage_capacity_l + 1;
        assert!(simulate(&config).is_err());
        let mut config = base_config();
        config.disruption.as_mut().unwrap().import_cut_bps = 10_001;
        assert!(simulate(&config).is_err());
    }
}
