use safrb_core::{canonical_disruption_suite, simulate, ScenarioConfig};

fn main() -> Result<(), String> {
    // These values are illustrative fixtures, not estimates of current
    // South African production, stocks or import receipts.
    let historical_demand_baseline_l_per_day = 32_300_000_u64;
    let base = ScenarioConfig {
        scenario_id: "illustrative-synthetic-base".into(),
        horizon_days: 37,
        opening_verified_usable_l: historical_demand_baseline_l_per_day * 7,
        storage_capacity_l: historical_demand_baseline_l_per_day * 30,
        daily_domestic_production_l: historical_demand_baseline_l_per_day * 30 / 100,
        daily_import_discharge_l: historical_demand_baseline_l_per_day * 70 / 100,
        daily_demand_l: historical_demand_baseline_l_per_day,
        max_import_receipts_l_per_day: historical_demand_baseline_l_per_day * 2,
        disruption: None,
    };

    println!("# SAFRB v0.1 — illustrative synthetic stress suite");
    println!("# Demand anchor: rounded 2024 historical working baseline only; all other rates/stocks below are synthetic assumptions.");
    println!("# No output is a current stock estimate, shortage forecast, or operational recommendation.");
    println!("scenario_id,disruption_days,horizon_days,first_shortfall_day,cumulative_unserved_l,ending_inventory_l,max_balance_residual_l");

    for scenario in canonical_disruption_suite(&base, 10_000)? {
        let duration = scenario.disruption.map_or(0, |shock| shock.duration_days);
        let result = simulate(&scenario)?;
        let first_shortfall = result
            .first_shortfall_day
            .map_or_else(|| "none".to_string(), |day| day.to_string());
        println!(
            "{},{},{},{},{},{},{}",
            result.scenario_id,
            duration,
            scenario.horizon_days,
            first_shortfall,
            result.cumulative_unserved_l,
            result.ending_inventory_l,
            result.max_absolute_balance_residual_l
        );
    }
    Ok(())
}
