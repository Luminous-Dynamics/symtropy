# South African Fuel Resilience Benchmark (SAFRB) — v0.1 kernel

**Repository placement:** `Luminous-Dynamics/symtropy/benchmarks/fuel-resilience/south-africa/v0.1/`  
**Status:** research prototype; not operationally validated  
**Implementation:** dependency-free Rust 2024  
**Evidence cut:** 2026-11-23

SAFRB is a public benchmark for testing whether fuel-system decisions remain physically balanced, evidence-qualified and resilient under disruption. The first kernel deliberately starts with a single national diesel balance. It does not yet claim to be a spatially resolved South African digital twin.

## What v0.1 actually implements

- Typed separation of **evidence class** from **physical stock/cargo state**.
- An inventory validator that admits only measured, quality-released and physically accessible `VerifiedUsable` volumes into opening usable stocks.
- Explicit exclusion of reported-but-unverified stock, commitments, pipeline line-fill, nominated/loaded/in-transit/arrived/discharged cargo from immediately usable stock.
- A monotonic cargo-milestone register: nominated → loaded → departed → in-transit → arrived → discharged.
- A deterministic daily mass-balance simulator with storage capacity, import-receipt ceiling, production interruption, import interruption, demand response, delays and unserved demand.
- Canonical 7/14/30/60/90-day import-shock durations plus a 30-day recovery tail.
- A JSON Schema for inventory observations and tests for evidence admission, duplicate observations, cargo progression, fail-closed inputs and daily conservation.

The five disruption durations are **stress-test cases, not forecasts**. The executable uses a rounded 2024 historical daily-demand anchor and otherwise synthetic values. Nothing in its output is a current national stock estimate, a prediction of a shortage date, or an operational recommendation.

## Run

From this directory:

```sh
cargo fmt --check
cargo test --locked
cargo clippy --all-targets --locked -- -D warnings
cargo run --release
```

The executable emits a CSV scorecard. v0.1 has no third-party dependencies and does not access the network.

## Core accounting invariant

For every simulated day:

```text
opening_inventory
+ domestic_production
+ discharged_import_receipts
- delivered_demand
- storage_overflow
- closing_inventory
= 0
```

Unserved demand is reported separately; it is not silently converted into negative inventory. Imported volumes are counted only when they are discharged into the modelled system. Cargo nominations, bills of lading, vessel positions and ETAs are not treated as stock.

## Evidence semantics

| State | Counted in immediately usable inventory? | Why |
|---|---:|---|
| ReportedPhysical | No | Reported amount is not an independent usable-stock measurement |
| MeasuredPhysical | No | A measured quantity may still be off-spec, inaccessible or unavailable |
| VerifiedUsable | Yes | Requires measured evidence, digest, quality release and accessibility |
| Committed | No | A contract or allocation is not physical stock |
| PipelineLineFill | No | Product occupying a pipeline is not automatically withdrawable national reserve |
| CargoNominated / Loaded / Departed / InTransit / Arrived | No | Milestones do not prove discharge and usable product |
| CargoDischarged | Not by itself | Discharge must still be quality-released and reconciled into usable inventory |

The model preserves source URI, source ID, valid time, recorded time, raw SHA-256 and uncertainty bounds. Mycelix can later provide signed issuer identity, custody transitions, selective-disclosure proofs and replayable attestation receipts. High-volume telemetry belongs in a time-series store, not on a distributed ledger.

## Known limitations — do not overclaim

- One aggregate diesel pool only: no province, terminal, refinery, pipeline, rail, road, berth, vessel or tank network yet.
- No multi-product compatibility, batch sequencing, contamination, density/temperature conversion, heel/dead-stock, tank operating limits or linepack dynamics.
- No stochastic arrivals, correlated supplier/port/refinery failures, optimization, demand-sector priority or substitution.
- No causal inference, ML forecasting, model calibration, uncertainty propagation or physical hydraulics yet.
- No live or confidential operational data; all non-demand demonstration parameters are synthetic.
- The current mass-balance oracle proves the software's accounting identity, not that the inputs represent the real world.

## Next benchmark increments

1. **v0.2 — time-expanded network:** Island View/coastal storage → inland accumulation → provincial demand zones; product-specific arcs, transfer lead times, pipeline/rail/road capacities, outage dependencies and tank constraints.
2. **v0.3 — decision tournament:** minimum-cost flow/LP baseline, deterministic robust planning, scenario-tree stochastic planning, and demand-response alternatives. Score unserved critical demand, economic cost, resilience regret and recovery time.
3. **v0.4 — evidence and adversarial suite:** duplicate/late/reordered events, conflicting trade records, forged certificates, unit errors, cargo-stage spoofing, inaccessible tanks, off-spec batches, common-cause failures and strategic reporting incentives.
4. **v0.5 — causal and predictive evaluation:** Symthaea fault hypotheses and forecast comparisons against persistence, seasonal-naive, ETS/ARIMA, gradient-boosted trees, PCA/PLS and domain-rule baselines.
5. **v1.0 — independent qualification:** actual asset/operator data, calibrated uncertainty, reproducible replays, independent engineering review and written limits of applicability.

## Luminous platform boundary

- **Symtropy:** conservation-respecting network and physical models; counterfactual simulation and deterministic replay.
- **Symthaea:** causal hypothesis generation, evidence-seeking, forecasting and explanation; it cannot convert its own prediction into ground truth.
- **Mycelix:** source identity, signed observations, custody events, selective disclosure and audit receipts.
- **Sol-Atlas:** geospatial assets, corridors, rights, communities, protected areas, environmental exposure and access constraints.
- **Independent qualification:** baseline tournament, data-quality controls, physical invariants, uncertainty calibration and human authority.

The first executable is intentionally independent of all four platforms so it can serve as a neutral oracle. Adapters should be introduced only after the benchmark contract is stable.
